package com.example.flymessagedome.bean.socketData;

public class BaseSocketData {
    public int msgType;

    public int getMsgType() {
        return msgType;
    }

    public void setMsgType(int msgType) {
        this.msgType = msgType;
    }
}
