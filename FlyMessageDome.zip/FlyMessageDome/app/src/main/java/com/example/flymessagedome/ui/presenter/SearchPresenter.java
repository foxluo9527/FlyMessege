package com.example.flymessagedome.ui.presenter;

import com.example.flymessagedome.api.FlyMessageApi;
import com.example.flymessagedome.base.RxPresenter;
import com.example.flymessagedome.model.Login;
import com.example.flymessagedome.model.SearchUserModel;
import com.example.flymessagedome.ui.activity.MainActivity;
import com.example.flymessagedome.ui.contract.SearchContract;
import com.example.flymessagedome.utils.Constant;
import com.example.flymessagedome.utils.SharedPreferencesUtil;

import java.util.ArrayList;

import javax.inject.Inject;

import rx.Observer;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class SearchPresenter extends RxPresenter<SearchContract.View> implements SearchContract.Presenter<SearchContract.View> {
    private FlyMessageApi flyMessageApi;
    ArrayList<SearchUserModel.ResultBean> searchUsers;
    @Inject
    public SearchPresenter(FlyMessageApi flyMessageApi) {
        this.flyMessageApi = flyMessageApi;
    }

    @Override
    public void login(String userName, String password) {
        Subscription rxSubscription = flyMessageApi.getLogin(userName,password).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<Login>() {
                    @Override
                    public void onCompleted() {
                        mView.complete();
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mView.loginFailed(null);
                    }

                    @Override
                    public void onNext(Login login) {
                        if (login != null && mView != null && login.code == Constant.SUCCESS) {
                            SharedPreferencesUtil.getInstance().putString(Constant.U_NAME,userName);
                            SharedPreferencesUtil.getInstance().putString(Constant.U_PASS,password);
                            SharedPreferencesUtil.getInstance().putString(Constant.LOGIN_TOKEN,login.getToken());
                            if (!MainActivity.serviceBinder.getConnectState()){
                                MainActivity.serviceBinder.closeConnect();
                                MainActivity.serviceBinder.connect();
                            }
                        }else {
                            mView.loginFailed(login);
                        }
                    }
                });
        addSubscribe(rxSubscription);
    }

    @Override
    public void search(String content,int pageSize, int pageNum) {
        if (pageNum==1){
            searchUsers=new ArrayList<>();
        }
        Subscription rxSubscription = flyMessageApi.searchUser(content,pageSize,pageNum).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<SearchUserModel>() {
                    @Override
                    public void onCompleted() {
                        mView.complete();
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mView.loginFailed(null);
                    }

                    @Override
                    public void onNext(SearchUserModel userModel) {
                        if (userModel != null && mView != null && userModel.code == Constant.SUCCESS) {
                            if (searchUsers==null||searchUsers.size()==0){
                                searchUsers= (ArrayList<SearchUserModel.ResultBean>) userModel.getResult();
                            }else {
                                searchUsers.addAll(userModel.getResult());
                            }
                            if (userModel.getResult().size()==20){
                                search(content,pageSize,pageNum+1);
                            }else {
                                mView.initSearchResult(searchUsers);
                            }
                        }else if (userModel!=null&&userModel.code==Constant.NOT_LOGIN){
                            String u_name=SharedPreferencesUtil.getInstance().getString(Constant.U_NAME);
                            String pass=SharedPreferencesUtil.getInstance().getString(Constant.U_PASS);
                            login(u_name,pass);
                        }
                    }
                });
        addSubscribe(rxSubscription);
    }
}
