package com.example.flymessagedome.ui.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.flymessagedome.FlyMessageApplication;
import com.example.flymessagedome.R;
import com.example.flymessagedome.base.BaseActivity;
import com.example.flymessagedome.bean.FriendsBean;
import com.example.flymessagedome.bean.FriendsBeanDao;
import com.example.flymessagedome.bean.UserBean;
import com.example.flymessagedome.component.AppComponent;
import com.example.flymessagedome.model.Base;
import com.example.flymessagedome.model.CheckBlackListModel;
import com.example.flymessagedome.model.Users;
import com.example.flymessagedome.ui.fragment.FriendFragment;
import com.example.flymessagedome.utils.Constant;
import com.example.flymessagedome.utils.HttpRequest;
import com.example.flymessagedome.utils.ImageUtils;
import com.example.flymessagedome.utils.SharedPreferencesUtil;
import com.example.flymessagedome.utils.ToastUtils;
import com.example.flymessagedome.view.CircleImageView;

import butterknife.BindView;
import butterknife.OnClick;

public class ShowUserActivity extends BaseActivity implements MenuItem.OnMenuItemClickListener {
    String user_name;
    @BindView(R.id.nick_name)
    TextView nickName;
    @BindView(R.id.u_name)
    TextView u_name;
    @BindView(R.id.position)
    TextView position;
    @BindView(R.id.sex)
    ImageView sex;
    @BindView(R.id.u_head_img)
    CircleImageView headImg;
    @BindView(R.id.main_view)
    ImageView mainView;
    @BindView(R.id.sgin)
    TextView sgin;
    @BindView(R.id.add_fri_btn)
    Button add_fri;
    @Override
    public int getLayoutId() {
        return R.layout.activity_show_user;
    }
    UserBean userBean;
    boolean inBlackList=false;
    FriendsBeanDao friendsBeanDao=FlyMessageApplication.getInstances().getDaoSession().getFriendsBeanDao();
    @Override
    protected void setupActivityComponent(AppComponent appComponent) {

    }

    @Override
    public void initDatas() {
        user_name=getIntent().getStringExtra("userName");
        if (TextUtils.isEmpty(user_name)){
            ToastUtils.showToast("用户名错误");
            finish();
            return;
        }
        showLoadingDialog(true,"数据加载中");
        new AsyncTask<Void,Void, Users>() {
            @Override
            protected Users doInBackground(Void... voids) {
                String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
                return HttpRequest.getUserMsg(user_name,loginToken);
            }
            @Override
            protected void onPostExecute(Users user) {
                userBean=user.getUser();
                if (userBean==null){
                    ToastUtils.showToast(user.msg);
                    finish();
                    return;
                }
                new AsyncTask<Void,Void, CheckBlackListModel>() {
                    @Override
                    protected CheckBlackListModel doInBackground(Void... voids) {
                        return HttpRequest.checkBlackList(userBean.getU_id());
                    }
                    @Override
                    protected void onPostExecute(CheckBlackListModel blackListModel) {
                        dismissLoadingDialog();
                        inBlackList=blackListModel.inBlacklist;
                    }
                }.execute();
                Glide.with(mContext)
                        .load(FlyMessageApplication.getProxy(mContext).getProxyUrl(userBean.getU_head_img()))
                        .into(headImg);
                Glide.with(mContext)
                        .asDrawable()
                        .load(FlyMessageApplication.getProxy(mContext).getProxyUrl(userBean.getU_bg_img()))
                        .into(mainView);
                sgin.setText(userBean.getU_sign());
                if (userBean.getU_sex()==null){
                    sex.setVisibility(View.GONE);
                }else if (userBean.getU_sex().equals("男")){
                    sex.setImageDrawable(AppCompatResources.getDrawable(mContext,R.mipmap.man));
                }else if (userBean.getU_sex().equals("女")){
                    sex.setImageDrawable(AppCompatResources.getDrawable(mContext,R.mipmap.women));
                }
                nickName.setText(userBean.getU_nick_name());
                u_name.setText(userBean.getU_name());
                position.setText(userBean.getU_position());
                if (userBean.getIsFriend()){
                    add_fri.setVisibility(View.GONE);
                }
            }
        }.execute();
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @OnClick({R.id.back,R.id.user_set,R.id.nick_name,R.id.send_btn,R.id.add_fri_btn})
    public void onViewClick(View view){
        switch (view.getId()){
            case R.id.u_name:
                PopupMenu popup = new PopupMenu(mContext, view);
                MenuInflater inflater = popup.getMenuInflater();
                inflater.inflate(R.menu.home_friend_list_menu, popup.getMenu());
                popup.setOnMenuItemClickListener(ShowUserActivity.this::onMenuItemClick);
                popup.show();
                break;
            case R.id.back:
                finish();
                break;
            case R.id.user_set:
                showListPopupMenu(mContext);
                break;
            case R.id.send_btn:
                Intent intent=new Intent(mContext, UserChatActivity.class);
                intent.putExtra("userId",userBean.getU_id());
                startActivity(intent);
                break;
            case R.id.add_fri_btn:
                Intent rq_intent=new Intent(mContext,RequestFriendActivity.class);
                rq_intent.putExtra("uName",userBean.getU_name());
                startActivity(rq_intent);
                break;
        }
    }
    @Override
    public void configViews() {

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void showListPopupMenu(Context context) {
        final View popView = View.inflate(context,R.layout.friend_more_popup,null);
        TextView black_list_state=popView.findViewById(R.id.blacklist_state);
        TextView fri_state=popView.findViewById(R.id.fri_state);
        View changeRmk=popView.findViewById(R.id.change_rmk);
        View add_fri=popView.findViewById(R.id.add_fri);
        if (userBean.getIsFriend()){
            fri_state.setText("删除好友");
        }else {
            changeRmk.setVisibility(View.GONE);
            fri_state.setText("添加好友");
        }
        if (inBlackList){
            black_list_state.setText("移出黑名单");
        }else {
            black_list_state.setText("加入黑名单");
        }
        //获取屏幕宽高
        int weight = getResources().getDisplayMetrics().widthPixels;
        int height;
        if (userBean.getIsFriend())
            height = ImageUtils.dip2px(mContext,200);
        else {
            height = ImageUtils.dip2px(mContext,165);
        }
        PopupWindow popupWindow = new PopupWindow(popView,weight,height);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setFocusable(true);
        //点击外部popueWindow消失
        popupWindow.setOutsideTouchable(true);
        popupWindow.update();

        //popupWindow消失屏幕变为不透明
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = ((Activity)context).getWindow().getAttributes();
                lp.alpha = 1.0f;
                ((Activity)context).getWindow().setAttributes(lp);
            }
        });
        //popupWindow出现屏幕变为半透明
        WindowManager.LayoutParams lp =  ((Activity)context).getWindow().getAttributes();
        lp.alpha = 0.5f;
        ((Activity)context).getWindow().setAttributes(lp);
        View.OnClickListener listener=new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()){
                    case R.id.change_rmk:
                        FriendsBean friendsBean=FlyMessageApplication.getInstances().getDaoSession().getFriendsBeanDao().queryBuilder()
                                .where(FriendsBeanDao.Properties.F_source_u_id.eq(LoginActivity.loginUser.getU_id()))
                                .where(FriendsBeanDao.Properties.F_object_u_id.eq(userBean.getU_id()))
                                .unique();
                        if (friendsBeanDao!=null){
                            Intent rmkIntent=new Intent(mContext, ChangeRemarkNameActivity.class);
                            rmkIntent.putExtra("userId",userBean.getU_id());
                            rmkIntent.putExtra("fId",friendsBean.getF_id());
                            startActivity(rmkIntent);
                        }
                        popupWindow.dismiss();
                        break;
                    case R.id.black_list:
                        showLoadingDialog(false,"正在操作");
                        new AsyncTask<Void,Void,Base>() {
                            @Override
                            protected Base doInBackground(Void... voids) {
                                CheckBlackListModel blackListModel=HttpRequest.checkBlackList(userBean.getU_id());
                                inBlackList=blackListModel.inBlacklist;
                                if (inBlackList){
                                    return HttpRequest.delBlackList(userBean.getU_id());
                                }else {
                                    return HttpRequest.addBlackList(userBean.getU_id());
                                }
                            }
                            @Override
                            protected void onPostExecute(Base base) {
                                dismissLoadingDialog();
                                if (base.code== Constant.SUCCESS){
                                    inBlackList=!inBlackList;
                                    ToastUtils.showToast("操作成功");
                                }else {
                                    ToastUtils.showToast("操作失败");
                                }
                            }
                        }.execute();
                        popupWindow.dismiss();
                        break;
                    case R.id.add_fri:
                        if (userBean.getIsFriend()){
                            AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
                            dialog.setMessage("确认删除此联系人")
                                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            showLoadingDialog(false,"正在删除");
                                            new AsyncTask<Void,Void,Base>() {
                                                @Override
                                                protected Base doInBackground(Void... voids) {
                                                   return HttpRequest.delFriend(userBean.getF_id());
                                                }
                                                @Override
                                                protected void onPostExecute(Base base) {
                                                    dismissLoadingDialog();
                                                    if (base.code== Constant.SUCCESS){
                                                        inBlackList=!inBlackList;
                                                        ToastUtils.showToast("操作成功");
                                                    }else {
                                                        ToastUtils.showToast("操作失败");
                                                    }
                                                }
                                            }.execute();
                                        }})
                                    .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();//取消弹出框
                                        }
                                    })
                                    .create().show();
                        }else {
                            popupWindow.dismiss();
                            Intent rq_intent=new Intent(mContext,RequestFriendActivity.class);
                            rq_intent.putExtra("uName",userBean.getU_name());
                            startActivity(rq_intent);
                        }
                        break;
                    case R.id.cancel:
                        popupWindow.dismiss();
                        break;
                }
            }
        };
        changeRmk.setOnClickListener(listener);
        View black_list=popView.findViewById(R.id.black_list);
        black_list.setOnClickListener(listener);
        add_fri.setOnClickListener(listener);
        View cancel=popView.findViewById(R.id.cancel);
        cancel.setOnClickListener(listener);

        popupWindow.showAtLocation(popView, Gravity.BOTTOM,0,0);
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        if (item.getItemId()==R.id.remark_name){

        }
        return false;
    }
}
