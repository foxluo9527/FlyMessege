package com.example.flymessagedome.ui.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.arialyy.aria.core.Aria;
import com.example.flymessagedome.FlyMessageApplication;
import com.example.flymessagedome.R;
import com.example.flymessagedome.base.BaseActivity;
import com.example.flymessagedome.bean.DownloadTaskBean;
import com.example.flymessagedome.bean.GroupBean;
import com.example.flymessagedome.bean.Message;
import com.example.flymessagedome.bean.MessageDao;
import com.example.flymessagedome.bean.UserBean;
import com.example.flymessagedome.bean.UserBeanDao;
import com.example.flymessagedome.component.AppComponent;
import com.example.flymessagedome.component.DaggerMessageComponent;
import com.example.flymessagedome.model.Login;
import com.example.flymessagedome.service.MessageService;
import com.example.flymessagedome.ui.ImageViewCheckBox;
import com.example.flymessagedome.ui.adapter.ChatPhotoViewAdapter;
import com.example.flymessagedome.ui.adapter.MessageAdapter;
import com.example.flymessagedome.ui.contract.GroupMessageContract;
import com.example.flymessagedome.ui.presenter.GroupMessagePresenter;
import com.example.flymessagedome.utils.ActivityCollector;
import com.example.flymessagedome.utils.Constant;
import com.example.flymessagedome.utils.NetworkUtils;
import com.example.flymessagedome.utils.SharedPreferencesUtil;
import com.example.flymessagedome.utils.ToastUtils;
import com.lewis_v.audiohandle.play.AudioPlayManager;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import io.github.rockerhieu.emojicon.EmojiconGridFragment;
import io.github.rockerhieu.emojicon.EmojiconMultiAutoCompleteTextView;
import io.github.rockerhieu.emojicon.EmojiconsFragment;
import io.github.rockerhieu.emojicon.emoji.Emojicon;
import pub.devrel.easypermissions.EasyPermissions;

import static com.example.flymessagedome.service.MessageService.MSG_TYPE;
import static com.example.flymessagedome.service.MessageService.SERVICE_DISCONNECT;
import static com.example.flymessagedome.service.MessageService.SOCKET_SERVICE_ACTION;

public class GroupChatActivity extends BaseActivity implements GroupMessageContract.View,EmojiconGridFragment.OnEmojiconClickedListener, EmojiconsFragment.OnEmojiconBackspaceClickedListener
        , EasyPermissions.PermissionCallbacks{
    private static final String TAG = "FlyMessage";
    @BindView(R.id.send_voice)
    ImageViewCheckBox send_voice;
    @BindView(R.id.send_pic)
    ImageViewCheckBox send_pic;
    @BindView(R.id.take_photo)
    ImageViewCheckBox take_photo;
    @BindView(R.id.send_file)
    ImageViewCheckBox send_file;
    @BindView(R.id.send_voice_control)
    ImageViewCheckBox send_voice_control;
    @BindView(R.id.send_voice_cancel)
    ImageView send_voice_cancel;
    @BindView(R.id.tv_name)
    TextView name;
    @BindView(R.id.send_voice_state_tv)
    TextView send_voice_state_tv;
    @BindView(R.id.msg_et)
    EmojiconMultiAutoCompleteTextView msgTv;
    @BindView(R.id.send_btn)
    Button sendBtn;
    @BindView(R.id.messge_list)
    RecyclerView recyclerView;
    @BindView(R.id.voice_view)
    View voiceView;
    @BindView(R.id.photo_view)
    View photoView;
    @BindView(R.id.photos_list)
    RecyclerView photoList;
    @BindView(R.id.get_photo)
    TextView getPhoto;
    @BindView(R.id.send_img_btn)
    Button sendImgBtn;
    @BindView(R.id.emojicons)
    View emojisView;
    @BindView(R.id.cancel_choice)
    TextView cancelChoice;
    @BindView(R.id.tv_record)
    TextView recordMsg;

    public Context context=this;
    ArrayList<String> photoUrls=new ArrayList<>();
    UserBeanDao userBeanDao= FlyMessageApplication.getInstances().getDaoSession().getUserBeanDao();
    MessageDao messageDao=FlyMessageApplication.getInstances().getDaoSession().getMessageDao();
    MessageAdapter messageAdapter;
    ChatPhotoViewAdapter photoViewAdapter;
    GroupBean group;

    @Inject
    GroupMessagePresenter groupMessagePresenter;

    //消息列表
    private ArrayList<Message> messages;
    //消息中的图片列表
    private ArrayList<MessageAdapter.photoMap> photoMaps=new ArrayList<>();
    //消息中图片列表的url
    private ArrayList<String> showPhotoUrls=new ArrayList<>();
    //发送图片时选中的图片位置集合
    public ArrayList<Integer> choiceIndex=new ArrayList<>();
    //文件消息下载列表
    public ArrayList<DownloadTaskBean> downloadTasks=new ArrayList<>();
    //发送图片信息时所有的图片地址列表
    public static boolean choice[];
    //所有语音信息的播放状态
    public static boolean[] viocePlay;
    //本次播放的语音与上次播放的位置是否相同，判断是否暂停
    private boolean playStateChanged=false;
    //输入框内容
    private String content=null;
    //正在录音
    private boolean onRecording=false;
    //最后次播放语音的消息id
    private long lastPlayMid=0;
    //选中发送的图片张数
    private int choiceNum=0;
    //点击图片进入预览时，当前是第几张图片
    private int showPhotoPosition=0;

    @Override
    public int getLayoutId() {
        return R.layout.activity_group_chat;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferencesUtil.getInstance().putInt("onChatUserId",-1);
        if (!TextUtils.isEmpty(content))
            groupMessagePresenter.inserting(group,content);
        if (AudioPlayManager.getInstance().getPlayStatus().toString().equals("FREE")){
            AudioPlayManager.getInstance().stop();
            AudioPlayManager.getInstance().destory();
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Aria.download(this).register();
    }

    @Override
    protected void setupActivityComponent(AppComponent appComponent) {
        DaggerMessageComponent.builder().appComponent(appComponent).build().inject(this);
    }

    @Override
    public void initDatas() {

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //退出时若输入框内有文字
        if (!TextUtils.isEmpty(content))
            groupMessagePresenter.inserting(group,content);
    }

    @Override
    protected void loginRemote() {
        super.loginRemote();
        Log.e(TAG,"异地登陆，请重新登录");
        ToastUtils.showToast("异地登陆，请重新登录");
        LoginActivity.loginUser=null;
        ActivityCollector.finishAll();
        LoginActivity.startActivity(this);
    }

    @Override
    protected void receiveUserMessage() {
        super.receiveUserMessage();
        super.receiveUserMessage();
        int onChatGroupId=SharedPreferencesUtil.getInstance().getInt("onChatGroupId",-1);
        if (group!=null&& MessageService.isRunningForeground(this)&&onChatGroupId==group.getG_id())
            groupMessagePresenter.getMessages(group,true);
        else
            groupMessagePresenter.getMessages(group,false);
    }

    @Override
    public void configViews() {
        groupMessagePresenter.attachView(this);
    }

    @Override
    public void onEmojiconClicked(Emojicon emojicon) {
        EmojiconsFragment.input(msgTv, emojicon);
    }

    @Override
    public void onEmojiconBackspaceClicked(View v) {
        EmojiconsFragment.backspace(msgTv);
    }

    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {

    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {

    }

    @Override
    public void initData() {
        initDatas();
    }

    @Override
    public void initGroupMsg() {
        name.setText(""+group.getG_name());
        SharedPreferencesUtil.getInstance().putInt("onChatGroupId",(int) group.getG_id());
    }

    @Override
    public void initDataFailed() {
        dismissLoadingDialog();
        ToastUtils.showToast("数据获取失败");
        finish();
    }

    @Override
    public void initMessage(ArrayList<Message> messages) {

    }

    @Override
    public void loginFailed(Login login) {
        dismissLoadingDialog();
        groupMessagePresenter.getMessages(group,true);
        if (!NetworkUtils.isConnected(mContext)||login==null){
            Intent actionIntent = new Intent(SOCKET_SERVICE_ACTION);
            actionIntent.putExtra(MSG_TYPE,SERVICE_DISCONNECT);
            mContext.sendBroadcast(actionIntent);
        }else if (login!=null&&login.code== Constant.FAILED) {
            Log.e(TAG, "获取用户登录信息失败，请重新登录");
            ToastUtils.showToast("获取用户登录信息失败，请重新登录");
            SharedPreferencesUtil.getInstance().removeAll();
            ActivityCollector.finishAll();
            LoginActivity.startActivity(mContext);
        }
    }

    @Override
    public void sendFailed(Long m_id) {
        groupMessagePresenter.getMessages(group,true);
        dismissLoadingDialog();
        ToastUtils.showToast("消息发送失败");
        if (m_id!=null){
            Message sendMessage=messageDao.load(m_id);
        }
    }

    @Override
    public void sendSuccess() {
        dismissLoadingDialog();
        groupMessagePresenter.getMessages(group,true);
    }

    @Override
    public void initEntryTextToView(String text) {
        if (!TextUtils.isEmpty(text)&&msgTv!=null){
            msgTv.setText(""+text);
            sendBtn.setEnabled(true);
        }
    }

    @Override
    public void showError() {

    }

    @Override
    public void showError(String msg) {

    }

    @Override
    public void complete() {

    }

    @Override
    public void tokenExceed() {

    }

    public abstract class OnVerticalScrollListener extends RecyclerView.OnScrollListener {
        @Override
        public final void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            if (!recyclerView.canScrollVertically(-1)) {
                onScrolledToTop();
            } else if (!recyclerView.canScrollVertically(1)) {
                onScrolledToBottom();
            } else if (dy < 0) {
                onScrolledUp();
            } else if (dy > 0) {
                onScrolledDown();
            }
        }
        public void onScrolledUp() {}
        public void onScrolledDown() {}
        public void onScrolledToTop() {}
        public void onScrolledToBottom() {}
    }
}
