package com.example.flymessagedome.ui.presenter;

import com.example.flymessagedome.api.FlyMessageApi;
import com.example.flymessagedome.base.RxPresenter;
import com.example.flymessagedome.bean.GroupBean;
import com.example.flymessagedome.bean.Message;
import com.example.flymessagedome.bean.UserBean;
import com.example.flymessagedome.ui.contract.GroupMessageContract;

import javax.inject.Inject;

public class GroupMessagePresenter extends RxPresenter<GroupMessageContract.View> implements GroupMessageContract.Presenter<GroupMessageContract.View>{
    private FlyMessageApi flyMessageApi;

    @Inject
    public GroupMessagePresenter(FlyMessageApi flyMessageApi) {
        this.flyMessageApi = flyMessageApi;
    }

    @Override
    public void getGroupMsg(long groupId, boolean reset) {

    }

    @Override
    public void getMessages(GroupBean group, boolean read) {

    }

    @Override
    public void login(String userName, String password) {

    }

    @Override
    public void sendUserMessage(String fileUrl,GroupBean group, int m_content_type, String content) {

    }

    @Override
    public void inserting(GroupBean group, String content) {

    }

    @Override
    public void getEntryText() {

    }

    @Override
    public void initUserChat(GroupBean group) {

    }

    @Override
    public void delMessage(GroupBean group, int position) {

    }

    @Override
    public void reSendMessage(Message message, GroupBean group) {

    }
}
