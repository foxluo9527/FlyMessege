package com.example.flymessagedome.bean;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class GroupBean {

    /**
     * g_create_time : 1590137700000
     * g_name : 测试群聊
     * g_id : 6
     * g_num : dce6a25a-b4af-4014-b94d-d417f88d6a0f
     * g_head_img : http://www.foxluo.cn/FlyMessage/images/defaultGroupHead.png
     * g_introduce : 群聊简介
     */

    private long g_create_time;
    private String g_name;
    @Id
    private long g_id;
    private String g_num;
    private String g_head_img;
    private String g_introduce;

    @Generated(hash = 1449779577)
    public GroupBean(long g_create_time, String g_name, long g_id, String g_num,
            String g_head_img, String g_introduce) {
        this.g_create_time = g_create_time;
        this.g_name = g_name;
        this.g_id = g_id;
        this.g_num = g_num;
        this.g_head_img = g_head_img;
        this.g_introduce = g_introduce;
    }

    @Generated(hash = 405578774)
    public GroupBean() {
    }

    public long getG_create_time() {
        return g_create_time;
    }

    public void setG_create_time(long g_create_time) {
        this.g_create_time = g_create_time;
    }

    public String getG_name() {
        return g_name;
    }

    public void setG_name(String g_name) {
        this.g_name = g_name;
    }

    public long getG_id() {
        return g_id;
    }

    public void setG_id(long g_id) {
        this.g_id = g_id;
    }

    public String getG_num() {
        return g_num;
    }

    public void setG_num(String g_num) {
        this.g_num = g_num;
    }

    public String getG_head_img() {
        return g_head_img;
    }

    public void setG_head_img(String g_head_img) {
        this.g_head_img = g_head_img;
    }

    public String getG_introduce() {
        return g_introduce;
    }

    public void setG_introduce(String g_introduce) {
        this.g_introduce = g_introduce;
    }
}