package com.example.flymessagedome.model;

public class ChangeBgModel extends Base {
    String bgUrl;

    public String getBgUrl() {
        return bgUrl;
    }

    public void setBgUrl(String bgUrl) {
        this.bgUrl = bgUrl;
    }
}
