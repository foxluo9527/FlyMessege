package com.example.flymessagedome.component;

import androidx.fragment.app.FragmentActivity;

import com.example.flymessagedome.service.MessageService;
import com.example.flymessagedome.ui.activity.EditUserMsgActivity;
import com.example.flymessagedome.ui.activity.FriendRequestActivity;
import com.example.flymessagedome.ui.activity.GroupChatActivity;
import com.example.flymessagedome.ui.activity.LoginActivity;
import com.example.flymessagedome.ui.activity.MainActivity;
import com.example.flymessagedome.ui.activity.SearchResultActivity;
import com.example.flymessagedome.ui.activity.UserChatActivity;
import com.example.flymessagedome.ui.activity.WebActivity;
import com.example.flymessagedome.ui.activity.WelcomeActivity;
import com.example.flymessagedome.ui.fragment.FriendFragment;
import com.example.flymessagedome.ui.fragment.MessageFragment;
import com.example.flymessagedome.ui.fragment.MineFragment;

import dagger.Component;

@Component(dependencies = AppComponent.class)
public interface MessageComponent {
    LoginActivity inject(LoginActivity loginActivity);
    WelcomeActivity inject(WelcomeActivity welcomeActivity);
    MessageService inject(MessageService messageService);
    MainActivity inject(MainActivity mainActivity);
    MessageFragment inject(MessageFragment messageFragment);
    UserChatActivity inject(UserChatActivity userChatActivity);
    GroupChatActivity inject(GroupChatActivity groupChatActivity);
    FriendFragment inject(FriendFragment friendFragment);
    SearchResultActivity inject(SearchResultActivity searchResultActivity);
    FriendRequestActivity inject(FriendRequestActivity friendRequestActivity);
    MineFragment inject(MineFragment mineFragment);
    EditUserMsgActivity inject(EditUserMsgActivity editUserMsgActivity);
}
