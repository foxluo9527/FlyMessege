package com.example.flymessagedome.ui.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.flymessagedome.R;
import com.example.flymessagedome.base.BaseActivity;
import com.example.flymessagedome.bean.UserBean;
import com.example.flymessagedome.component.AppComponent;
import com.example.flymessagedome.component.DaggerMessageComponent;
import com.example.flymessagedome.model.Login;
import com.example.flymessagedome.model.SearchUserModel;
import com.example.flymessagedome.ui.adapter.FriendAdapter;
import com.example.flymessagedome.ui.adapter.SearchUserAdapter;
import com.example.flymessagedome.ui.contract.SearchContract;
import com.example.flymessagedome.ui.presenter.SearchPresenter;
import com.example.flymessagedome.utils.ActivityCollector;
import com.example.flymessagedome.utils.Constant;
import com.example.flymessagedome.utils.NetworkUtils;
import com.example.flymessagedome.utils.SharedPreferencesUtil;
import com.example.flymessagedome.utils.ToastUtils;

import java.util.ArrayList;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

import static com.example.flymessagedome.service.MessageService.MSG_TYPE;
import static com.example.flymessagedome.service.MessageService.SERVICE_DISCONNECT;
import static com.example.flymessagedome.service.MessageService.SOCKET_SERVICE_ACTION;

public class SearchResultActivity extends BaseActivity implements SearchContract.View,SearchUserAdapter.OnRecyclerViewItemClickListener {
    private static final String TAG = "FlyMessage";
    @BindView(R.id.search_empty)
    TextView search_empty;
    @BindView(R.id.person_list)
    RecyclerView recyclerView;
    @BindView(R.id.et_search)
    EditText searchEt;
    @BindView(R.id.cancel_tv)
    TextView cancelTv;
    @BindView(R.id.cancel)
    ImageView cancel;
    ArrayList<SearchUserModel.ResultBean> userBeans;
    @Inject
    SearchPresenter searchPresenter;
    SearchUserAdapter adapter;
    @Override
    public int getLayoutId() {
        return R.layout.activity_search_result;
    }

    @Override
    protected void setupActivityComponent(AppComponent appComponent) {
        DaggerMessageComponent.builder().appComponent(appComponent).build().inject(this);
    }
    @OnClick({R.id.cancel,R.id.cancel_tv})
    public void onViewClick(View v){
        if(v.getId()==R.id.cancel_tv){
            if (cancelTv.getText().equals("取消")){
                finish();
            }else if (searchEt.getText().toString().length()>0){
                showLoadingDialog(false,"搜索用户信息中");
                searchPresenter.search(searchEt.getText().toString(),20,1);
            }
        }else {
            v.setVisibility(View.GONE);
            searchEt.setText("");
        }
    }

    @Override
    public void initDatas() {
        String searchWords=getIntent().getStringExtra("searchWords");
        if (!TextUtils.isEmpty(searchWords)){
            searchEt.setText(searchWords);
            cancelTv.setText("搜索");
            cancel.setVisibility(View.VISIBLE);
            showLoadingDialog(false,"搜索用户信息中");
            searchPresenter.search(searchWords,20,1);
        }
        searchEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().length()>0){
                    cancelTv.setText("搜索");
                    cancel.setVisibility(View.VISIBLE);
                }else {
                    cancelTv.setText("取消");
                    cancel.setVisibility(View.GONE);
                }
            }
        });

    }

    @Override
    public void configViews() {
        searchPresenter.attachView(this);
    }

    @Override
    public void initSearchResult(ArrayList<SearchUserModel.ResultBean> users) {
        dismissLoadingDialog();
        if (users!=null&&users.size()!=0){
            userBeans=users;
            adapter=new SearchUserAdapter(users,mContext,this::onItemClick);
            StaggeredGridLayoutManager msgGridLayoutManager=new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL);
            recyclerView.setLayoutManager(msgGridLayoutManager);
            ((SimpleItemAnimator)recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
            recyclerView.setAdapter(adapter);
            recyclerView.setHasFixedSize(true);
            recyclerView.setNestedScrollingEnabled(false);
            recyclerView.setVisibility(View.VISIBLE);
            search_empty.setVisibility(View.GONE);
        }else {
            recyclerView.setVisibility(View.GONE);
            search_empty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void loginFailed(Login login) {
        dismissLoadingDialog();
        if (!NetworkUtils.isConnected(mContext)||login==null){
            Intent actionIntent = new Intent(SOCKET_SERVICE_ACTION);
            actionIntent.putExtra(MSG_TYPE,SERVICE_DISCONNECT);
            mContext.sendBroadcast(actionIntent);
        }else if (login!=null&&login.code== Constant.FAILED) {
            Log.e(TAG, "获取用户登录信息失败，请重新登录");
            ToastUtils.showToast("获取用户登录信息失败，请重新登录");
            SharedPreferencesUtil.getInstance().removeAll();
            ActivityCollector.finishAll();
            LoginActivity.startActivity(mContext);
        }
    }

    @Override
    public void showError() {

    }

    @Override
    public void showError(String msg) {

    }

    @Override
    public void complete() {

    }

    @Override
    public void tokenExceed() {

    }

    @Override
    public void onItemClick(View view, int position) {
        Intent intent=new Intent(mContext,ShowUserActivity.class);
        intent.putExtra("userName",userBeans.get(position).getU_name());
        startActivity(intent);
    }
}
