package com.example.flymessagedome.model;

public class Base {
    public String msg;//接口提示信息
    public int code;//状态码
}
