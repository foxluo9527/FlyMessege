package com.example.flymessagedome.utils;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.example.flymessagedome.model.Base;
import com.example.flymessagedome.model.CheckBlackListModel;
import com.example.flymessagedome.model.Group;
import com.example.flymessagedome.model.GroupMemberModel;
import com.example.flymessagedome.model.GroupMembersModel;
import com.example.flymessagedome.model.Users;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HttpRequest {
    public static final String TAG="FlyMessageDome";
    public static Users getUserMsg(int id, String loginToken){
        Users users=null;
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"user/getUserByID?object_u_id="+id+"&loginToken="+loginToken);
        if (resultJson!=null){
            users= JSON.parseObject(resultJson.toString(),Users.class);
        }
        return users;
    }
    public static Users getUserMsg(String u_name, String loginToken){
        Users users=null;
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"user/getUserByName?u_name="+u_name+"&loginToken="+loginToken);
        if (resultJson!=null){
            users= JSON.parseObject(resultJson.toString(),Users.class);
        }
        return users;
    }
    public static Group getGroupMsg(int id, String loginToken){
        Group group=null;
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"group/getGroupMsg?g_id="+id+"&loginToken="+loginToken);
        if (resultJson!=null){
            group= JSON.parseObject(resultJson.toString(),Group.class);
        }
        return group;
    }
    public static GroupMemberModel getGroupMember(int id,int u_id, String loginToken){
        GroupMemberModel groupMember=null;
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"group/getGroupMemberById?g_id="+id+"&object_u_id="+u_id+"&loginToken="+
                loginToken);
        if (resultJson!=null){
            groupMember= JSON.parseObject(resultJson.toString(), GroupMemberModel.class);
        }
        return groupMember;
    }
    public static GroupMembersModel getGroupMembers(int id, String loginToken, int pageSize, int pageNum){
        GroupMembersModel groupMember=null;
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"group/getGroupMember?g_id="+id+"&loginToken="+
                loginToken+"&pageSize="+pageSize+"&pageIndex="+pageNum);
        if (resultJson!=null){
            groupMember= JSON.parseObject(resultJson.toString(), GroupMembersModel.class);
        }
        return groupMember;
    }
    public static Base changeRMKName(long f_id,String name){
        Base base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/changeFriendRemarkName?f_id="+f_id+"&loginToken="+
                loginToken+"&f_remarks_name="+name);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), Base.class);
        }
        return base;
    }
    public static CheckBlackListModel checkBlackList(long object_u_id){
        CheckBlackListModel base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/checkBlackList?object_u_id="+object_u_id+"&loginToken="+
                loginToken);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), CheckBlackListModel.class);
        }
        return base;
    }
    public static Base addBlackList(long object_u_id){
        Base base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/addBlackList?object_u_id="+object_u_id+"&loginToken="+
                loginToken);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), Base.class);
        }
        return base;
    }
    public static Base delBlackList(long object_u_id){
        Base base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/delBlackList?object_u_id="+object_u_id+"&loginToken="+
                loginToken);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), Base.class);
        }
        return base;
    }
    public static Base delFriend(long f_id){
        Base base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/delFriend?f_id="+f_id+"&loginToken="+
                loginToken);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), Base.class);
        }
        return base;
    }
    public static Base addFriendRequest(long object_u_id,String rq_content,String rq_remarks_name){
        Base base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/addFriendRequest?rq_object_u_id="+object_u_id+"&loginToken="+
                loginToken+"&rq_content="+rq_content+"&rq_remarks_name="+rq_remarks_name);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), Base.class);
        }
        return base;
    }
    public static Base acceptFriendRequest(long rq_id){
        Base base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/acceptFriendRequest?rq_id="+rq_id+"&loginToken="+
                loginToken);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), Base.class);
        }
        return base;
    }
    public static Base delFriendRequest(long rq_id){
        Base base=null;
        String loginToken= SharedPreferencesUtil.getInstance().getString("loginToken");
        JSONObject resultJson=OkHttpGet(Constant.API_BASE_URL+"friend/delFriendRequest?rq_id="+rq_id+"&loginToken="+
                loginToken);
        if (resultJson!=null){
            base= JSON.parseObject(resultJson.toString(), Base.class);
        }
        return base;
    }
    private static JSONObject OkHttpGet(String url){
        JSONObject resultJson=null;
        OkHttpClient okHttpClient = new OkHttpClient.Builder().readTimeout(50, TimeUnit.SECONDS).build();   //50毫秒内响应
        Request request = new Request.Builder().url(url).get().build();
        Call call = okHttpClient.newCall(request);
        try {
            Response response = call.execute();
            String result = response.body().string();
            Log.e(TAG,"response: " + result);
            try {
                resultJson=new JSONObject(result);
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultJson;
    }
}
