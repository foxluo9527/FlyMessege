package com.example.flymessagedome.model;

public class ChangeHeadModel extends Base {
    String headUrl;

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }
}
