package com.example.flymessagedome.service;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.Vibrator;
import android.text.TextUtils;
import android.widget.RemoteViews;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.alibaba.fastjson.JSON;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.danikula.videocache.HttpProxyCacheServer;
import com.example.flymessagedome.FlyMessageApplication;
import com.example.flymessagedome.R;
import com.example.flymessagedome.bean.Chat;
import com.example.flymessagedome.bean.ChatDao;
import com.example.flymessagedome.bean.FriendRequestDao;
import com.example.flymessagedome.bean.GroupBean;
import com.example.flymessagedome.bean.GroupBeanDao;
import com.example.flymessagedome.bean.GroupMemberDao;
import com.example.flymessagedome.bean.Message;
import com.example.flymessagedome.bean.MessageDao;
import com.example.flymessagedome.bean.UserBean;
import com.example.flymessagedome.bean.UserBeanDao;
import com.example.flymessagedome.bean.socketData.SocketFriendRequest;
import com.example.flymessagedome.bean.socketData.SocketLink;
import com.example.flymessagedome.bean.socketData.SocketMessage;
import com.example.flymessagedome.model.Group;
import com.example.flymessagedome.model.GroupMemberModel;
import com.example.flymessagedome.model.Users;
import com.example.flymessagedome.ui.activity.GroupChatActivity;
import com.example.flymessagedome.ui.activity.LoginActivity;
import com.example.flymessagedome.ui.activity.UserChatActivity;
import com.example.flymessagedome.utils.Constant;
import com.example.flymessagedome.utils.HttpRequest;
import com.example.flymessagedome.utils.MWebSocketClient;
import com.example.flymessagedome.utils.SharedPreferencesUtil;
import com.example.flymessagedome.utils.StringUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.util.Date;
import java.util.List;

public class MessageService extends Service {
    public Context context;
    public HttpProxyCacheServer proxy;

    public static final String SOCKET_SERVICE_ACTION="socketServiceAction";

    public static final String MSG_TYPE="messageType";

    //服务连接成功
    public static final int SERVICE_CONNECTED=0;
    //服务连接断开
    public static final int SERVICE_DISCONNECT=1;
    //收到消息
    public static final int RECEIVE_USER_MESSAGE=2;
    //收到好友验证
    public static final int RECEIVE_FRIEND_REQUEST=3;
    //异地登陆
    public static final int LOG_OUT=4;

    public MWebSocketClient client;

    private RemoteViews remoteView;
    private NotificationManager manager;
    private Notification notification;
    private String notificationChannelID = "30";

    //每隔3秒进行一次对长连接的心跳检测
    public static final long HEART_BEAT_RATE = 3* 1000;
    boolean keepHeart=true;
    
    UserBeanDao userBeanDao= FlyMessageApplication.getInstances().getDaoSession().getUserBeanDao();
    FriendRequestDao friendRequestDao=FlyMessageApplication.getInstances().getDaoSession().getFriendRequestDao();
    MessageDao messageDao=FlyMessageApplication.getInstances().getDaoSession().getMessageDao();
    GroupBeanDao groupBeanDao=FlyMessageApplication.getInstances().getDaoSession().getGroupBeanDao();
    GroupMemberDao groupMemberDao=FlyMessageApplication.getInstances().getDaoSession().getGroupMemberDao();
    ChatDao chatDao=FlyMessageApplication.getInstances().getDaoSession().getChatDao();
    public static int connCount=0;
    @Override
    public void onCreate() {
        super.onCreate();
        context=getApplicationContext();
        proxy=FlyMessageApplication.getProxy(context);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new MessageServiceBinder();
    }

    public class MessageServiceBinder extends Binder{
        public boolean connect(){
            try {
                getClient();
                connCount=0;
                if (client!=null){
                    client.connectBlocking();
                    sendMessageBroadcast(SERVICE_CONNECTED);
                    keepHeart();
                    return true;
                }else{
                    return false;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                return false;
            }
        }
        public void closeConnect() {
            try {
                if (null != client) {
                    client.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                client = null; //避免重复实例化WebSocketClient对象
            }
        }
        private void keepHeart() {
            new Thread(){
                @Override
                public void run() {
                    super.run();
                    while (true){
                        try {
                            if (client!=null&&keepHeart&&connCount<10){
                                connCount++;
                                if (client.isClosed()){
                                    client.reconnectBlocking();
                                }
                                if (client.isClosing()){
                                    client.onError(null);
                                    break;
                                }
                            }else {
                                break;
                            }
                            sleep(HEART_BEAT_RATE);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }.start();
        }
        public boolean getConnectState(){
            return client!=null&&client.isOpen();
        }
    }

    public void getClient(){
        if (!TextUtils.isEmpty(SharedPreferencesUtil.getInstance().getString(Constant.LOGIN_TOKEN))){
            URI uri = URI.create(Constant.SOCKET_BASE_URL+ "?loginToken="+SharedPreferencesUtil.getInstance().getString(Constant.LOGIN_TOKEN));
            client = new MWebSocketClient(uri) {
                @Override
                public void onMessage(String message) {
                    //对接收到的消息message进行处理
                    JSONObject messageJson= null;
                    try {
                        messageJson = new JSONObject(message);
                        switch (messageJson.optInt("msgType")){
                            case 1:
                                //普通消息
                                SocketMessage messageBean= JSON.parseObject(message,SocketMessage.class);
                                receiveMessage(messageBean);
                                break;
                            case 2:
                                //添加好友消息
                                SocketFriendRequest friendRequest=JSON.parseObject(message,SocketFriendRequest.class);
                                friendRequestDao.insertOrReplace(friendRequest.getContent());
                                sendMessageBroadcast(RECEIVE_FRIEND_REQUEST);
                                break;
                            case 3:
                                //链接消息
                                SocketLink link=JSON.parseObject(message,SocketLink.class);
                                break;
                            case 4:
                                //下线通知
//                                String loginToken=SharedPreferencesUtil.getInstance().getString("loginToken");
//                                if (messageJson.optInt("userId")==LoginActivity.loginUser.getU_id()&&
//                                !messageJson.optString("loginToken").equals(loginToken))
//                                    sendMessageBroadcast(LOG_OUT);
//                                else
//                                    sendMessageBroadcast(SERVICE_DISCONNECT);
                                sendMessageBroadcast(LOG_OUT);
                                break;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onError(Exception ex) {
                    super.onError(ex);
                    sendMessageBroadcast(SERVICE_DISCONNECT);
                }

            };
        }
    }
    Users users=null;
    Group group=null;
    GroupMemberModel groupMember=null;
    //接收到用户的消息
    public void receiveMessage(SocketMessage messageBean){
        Message message=messageBean.getContent();
        String loginToken=SharedPreferencesUtil.getInstance().getString(Constant.LOGIN_TOKEN);
        new AsyncTask<Void,Void,Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if (userBeanDao.load((long)message.getM_source_id())==null){
                    users=HttpRequest.getUserMsg(message.getM_source_id(),loginToken);
                }
                if (message.getM_type()==1&&groupBeanDao.load((long)message.getM_source_g_id())==null){
                    group=HttpRequest.getGroupMsg(message.getM_source_g_id(),loginToken);
                    if (groupMemberDao.queryBuilder()
                            .where(GroupMemberDao.Properties.G_id.eq(message.getM_source_g_id()))
                            .where(GroupMemberDao.Properties.U_id.eq(message.getM_source_id()))
                            .list().size()==0){
                        groupMember=HttpRequest.getGroupMember(message.getM_source_g_id(),message.getM_source_id(),loginToken);
                    }
                }
                return null;
            }
            @Override
            protected void onPostExecute(Void aVoid) {
                if (users != null && users.code == Constant.SUCCESS){
                    userBeanDao.insertOrReplace(users.getUser());
                    users=null;
                }
                if (group != null && group.code == Constant.SUCCESS) {
                    groupBeanDao.insertOrReplace(group.getGroup());
                    group=null;
                    if (groupMember!=null && groupMember.code == Constant.SUCCESS){
                        groupMemberDao.insertOrReplace(groupMember.getGroup_member());
                    }
                }
                initMessageNotification(message);
            }
        }.execute();
    }
    //构建用户消息推送
    public void initMessageNotification(Message message){
        message.setM_id(null);
        message.setIsSend(true);
        sendMessageBroadcast(RECEIVE_USER_MESSAGE);
        manager= (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "我的消息";
            String description = "好友/群聊消息";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(notificationChannelID, name, importance);
            mChannel.setDescription(description);
            mChannel.setAllowBubbles(true);
            mChannel.setLightColor(Color.RED);
            mChannel.enableLights(true);//是否显示通知指示灯
            mChannel.enableVibration(true);//是否振动
            mChannel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            mChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            manager.createNotificationChannel(mChannel);
        }
        remoteView=new RemoteViews(getPackageName(), R.layout.message_notification_view);

        String content= StringUtil.formatFileMessage(message.getM_content());
        UserBean userBean=userBeanDao.load((long)message.getM_source_id());
        if (userBean==null){
            return;
        }
        if (message.getM_type()==0){//用户消息
            List<Message> messages=messageDao.loadAll();
            messages=messageDao.queryBuilder()
                .where(MessageDao.Properties.M_source_id.eq(message.getM_source_id()))
                .where(MessageDao.Properties.M_type.eq(0))
                .where(MessageDao.Properties.M_receive_state.eq(0))
                .list();
            //添加或更新消息列表
            Chat userChat=chatDao.queryBuilder()
                    .where(ChatDao.Properties.Chat_type.eq(0))
                    .where(ChatDao.Properties.Source_id.eq(userBean.getU_id()))
                    .where(ChatDao.Properties.Object_u_id.eq(LoginActivity.loginUser.getU_id()))
                    .unique();
            if (userChat==null){
                userChat=new Chat();
                userChat.setChat_show_remind(true);
                userChat.setChat_up(false);
                userChat.setChat_type(0);
                userChat.setSource_g_id(0);
                userChat.setSource_id(userBean.getU_id());
                userChat.setObject_u_id(LoginActivity.loginUser.getU_id());
            }
            userChat.setChat_reshow(true);
            userChat.setChat_content(content);
            userChat.setChat_head(userBean.getU_head_img());
            userChat.setChat_m_count(messages.size()+1);
            userChat.setChat_name(userBean.getU_nick_name());
            userChat.setTime(new Date(message.getM_send_time()));
            chatDao.insertOrReplace(userChat);
            userChat=chatDao.queryBuilder()
                    .where(ChatDao.Properties.Chat_type.eq(0))
                    .where(ChatDao.Properties.Source_id.eq(userBean.getU_id()))
                    .where(ChatDao.Properties.Object_u_id.eq(LoginActivity.loginUser.getU_id()))
                    .unique();
            message.setCId(userChat.getC_id());
            messageDao.insertOrReplace(message);
            remoteView.setTextViewText(R.id.tv_u_name,userBean.getU_nick_name()+"("+(messages.size()+1)+"条新消息)");
            remoteView.setTextViewText(R.id.tv_msg_content,content);
            remoteView.setImageViewResource(R.id.notify_head_img,R.mipmap.ic_launcher);
            if (userChat.getChat_show_remind()) {
                Intent actionIntent=new Intent(this, UserChatActivity.class);
                actionIntent.putExtra("userId",userBean.getU_id());
                actionIntent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                PendingIntent intent = PendingIntent.getActivity(this, 0, actionIntent, PendingIntent.FLAG_CANCEL_CURRENT);
                int onChatUId=SharedPreferencesUtil.getInstance().getInt("onChatUserId",-1);
                if (onChatUId!=message.getM_source_id()||!isRunningForeground(FlyMessageApplication.getInstances().getApplicationContext()))
                    notifyUserMessage(userBean.getU_head_img(), (int) message.getCId(),intent);
            }
        }else {//群聊消息
            List<Message> messages=messageDao.queryBuilder()
                    .where(MessageDao.Properties.M_type.eq(1))
                    .where(MessageDao.Properties.M_receive_state.eq(0))
                    .where(MessageDao.Properties.M_source_g_id.eq(message.getM_source_g_id()))
                    .list();
            GroupBean groupBean=groupBeanDao.load((long)message.getM_source_g_id());
            if (groupBean==null){
                return;
            }
            if (groupMember!=null && groupMember.code == Constant.SUCCESS){
                content=groupMember.getGroup_member().getG_nick_name()+":"+content;
                groupMember=null;
            }else {
                content=userBean.getU_nick_name()+":"+content;
            }
            Chat userChat=chatDao.queryBuilder()
                    .where(ChatDao.Properties.Chat_type.eq(1))
                    .where(ChatDao.Properties.Source_g_id.eq(groupBean.getG_id()))
                    .where(ChatDao.Properties.Object_u_id.eq(LoginActivity.loginUser.getU_id()))
                    .unique();
            if (userChat==null){
                userChat=new Chat();
                userChat.setChat_show_remind(true);
                userChat.setChat_up(false);
                userChat.setChat_type(1);
                userChat.setSource_id(0);
                userChat.setSource_g_id(groupBean.getG_id());
                userChat.setObject_u_id(LoginActivity.loginUser.getU_id());
            }
            userChat.setChat_reshow(true);
            userChat.setChat_content(content);
            userChat.setChat_head(groupBean.getG_head_img());
            userChat.setChat_m_count(messages.size()+1);
            userChat.setChat_name(groupBean.getG_name());
            userChat.setTime(new Date(message.getM_send_time()));
            chatDao.insertOrReplace(userChat);
            userChat=chatDao.queryBuilder()
                    .where(ChatDao.Properties.Chat_type.eq(1))
                    .where(ChatDao.Properties.Source_g_id.eq(groupBean.getG_id()))
                    .where(ChatDao.Properties.Object_u_id.eq(LoginActivity.loginUser.getU_id()))
                    .unique();
            message.setCId(userChat.getC_id());
            messageDao.insertOrReplace(message);
            remoteView.setTextViewText(R.id.tv_u_name,groupBean.getG_name()+"("+(messages.size()+1)+"条新消息)");
            remoteView.setTextViewText(R.id.tv_msg_content,content);
            remoteView.setImageViewResource(R.id.notify_head_img,R.mipmap.ic_launcher);
            if (userChat.getChat_show_remind()){
                Intent actionIntent=new Intent(this, GroupChatActivity.class);
                actionIntent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                actionIntent.putExtra("groupId",groupBean.getG_id());
                PendingIntent intent = PendingIntent.getActivity(this, 0, actionIntent, PendingIntent.FLAG_CANCEL_CURRENT);
                int onChatUId=SharedPreferencesUtil.getInstance().getInt("onChatGroupId",-1);
                if (onChatUId!=message.getM_source_g_id()||!isRunningForeground(FlyMessageApplication.getInstances().getApplicationContext()))
                    notifyUserMessage(groupBean.getG_head_img(),(int) message.getCId()+10000,intent);
            }
        }
    }
    //发送用户消息推送
    public void notifyUserMessage(String headUrl,int notifyId,PendingIntent pendingIntent){

        headUrl=proxy.getProxyUrl(headUrl);
        try {
            Glide.with(context).asBitmap().load(headUrl)
                    .into(new SimpleTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            remoteView.setImageViewBitmap(R.id.notify_head_img,resource);
                            notification =new NotificationCompat.Builder(getApplicationContext(),notificationChannelID)
                                    .setSmallIcon(R.mipmap.ic_launcher_round)
                                    .setOngoing(false)
                                    .setContent(remoteView)
                                    .setPriority(NotificationCompat.PRIORITY_MAX)//设置最大优先级
                                    .setAutoCancel(true)
                                    .setContentIntent(pendingIntent)
                                    .setVibrate(new long[]{0, 1000, 1000, 1000})
                                    .setSound(Uri.parse("android.resource://" + getPackageName() + "/" +R.raw.message))
                                    .build();
                            manager.notify(notifyId,notification);
                            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                            r.play();
                            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                            vibrator.vibrate(500);
                        }
                    });
        }catch (Exception e){
            e.printStackTrace();

        }finally {
        }
    }

    //发送广播
    public void sendMessageBroadcast(int msgType){
        Intent actionIntent = new Intent(SOCKET_SERVICE_ACTION);
        actionIntent.putExtra(MSG_TYPE,msgType);
        context.sendBroadcast(actionIntent);
    }
    /**
     * 判断本应用是否已经位于最前端
     *
     * @param context
     * @return 本应用已经位于最前端时，返回 true；否则返回 false
     */
    public static boolean isRunningForeground(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcessInfoList = activityManager.getRunningAppProcesses();
        //枚举进程
        for (ActivityManager.RunningAppProcessInfo appProcessInfo : appProcessInfoList) {
            if (appProcessInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                if (appProcessInfo.processName.equals(context.getApplicationInfo().processName)) {
                    return true;
                }
            }
        }
        return false;
    }
}
